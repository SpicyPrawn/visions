<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-09-17 07:23:40 --> Config Class Initialized
INFO - 2025-09-17 07:23:40 --> Hooks Class Initialized
DEBUG - 2025-09-17 07:23:40 --> UTF-8 Support Enabled
INFO - 2025-09-17 07:23:40 --> Utf8 Class Initialized
INFO - 2025-09-17 07:23:40 --> URI Class Initialized
DEBUG - 2025-09-17 07:23:40 --> No URI present. Default controller set.
INFO - 2025-09-17 07:23:40 --> Router Class Initialized
INFO - 2025-09-17 07:23:40 --> Output Class Initialized
INFO - 2025-09-17 07:23:40 --> Security Class Initialized
DEBUG - 2025-09-17 07:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 07:23:40 --> Input Class Initialized
INFO - 2025-09-17 07:23:40 --> Language Class Initialized
INFO - 2025-09-17 07:23:40 --> Loader Class Initialized
INFO - 2025-09-17 07:23:40 --> Helper loaded: url_helper
INFO - 2025-09-17 07:23:40 --> Helper loaded: language_helper
DEBUG - 2025-09-17 07:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 07:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 07:23:40 --> Controller Class Initialized
INFO - 2025-09-17 07:24:04 --> Config Class Initialized
INFO - 2025-09-17 07:24:04 --> Hooks Class Initialized
DEBUG - 2025-09-17 07:24:04 --> UTF-8 Support Enabled
INFO - 2025-09-17 07:24:04 --> Utf8 Class Initialized
INFO - 2025-09-17 07:24:04 --> URI Class Initialized
DEBUG - 2025-09-17 07:24:04 --> No URI present. Default controller set.
INFO - 2025-09-17 07:24:04 --> Router Class Initialized
INFO - 2025-09-17 07:24:04 --> Output Class Initialized
INFO - 2025-09-17 07:24:04 --> Security Class Initialized
DEBUG - 2025-09-17 07:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 07:24:04 --> Input Class Initialized
INFO - 2025-09-17 07:24:04 --> Language Class Initialized
INFO - 2025-09-17 07:24:04 --> Loader Class Initialized
INFO - 2025-09-17 07:24:04 --> Helper loaded: url_helper
INFO - 2025-09-17 07:24:04 --> Helper loaded: language_helper
DEBUG - 2025-09-17 07:24:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 07:24:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 07:24:04 --> Controller Class Initialized
INFO - 2025-09-17 07:24:04 --> File loaded: C:\xampp9\htdocs\bagplayers\application\views\home.php
INFO - 2025-09-17 07:24:04 --> Final output sent to browser
DEBUG - 2025-09-17 07:24:04 --> Total execution time: 0.4246
INFO - 2025-09-17 07:34:52 --> Config Class Initialized
INFO - 2025-09-17 07:34:52 --> Hooks Class Initialized
DEBUG - 2025-09-17 07:34:52 --> UTF-8 Support Enabled
INFO - 2025-09-17 07:34:52 --> Utf8 Class Initialized
INFO - 2025-09-17 07:34:52 --> URI Class Initialized
DEBUG - 2025-09-17 07:34:52 --> No URI present. Default controller set.
INFO - 2025-09-17 07:34:52 --> Router Class Initialized
INFO - 2025-09-17 07:34:52 --> Output Class Initialized
INFO - 2025-09-17 07:34:52 --> Security Class Initialized
DEBUG - 2025-09-17 07:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 07:34:52 --> Input Class Initialized
INFO - 2025-09-17 07:34:52 --> Language Class Initialized
INFO - 2025-09-17 07:34:52 --> Loader Class Initialized
INFO - 2025-09-17 07:34:52 --> Helper loaded: url_helper
INFO - 2025-09-17 07:34:52 --> Helper loaded: language_helper
DEBUG - 2025-09-17 07:34:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 07:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 07:34:52 --> Controller Class Initialized
INFO - 2025-09-17 07:34:52 --> File loaded: C:\xampp9\htdocs\bagplayers\application\views\home.php
INFO - 2025-09-17 07:34:52 --> Final output sent to browser
DEBUG - 2025-09-17 07:34:52 --> Total execution time: 0.4440
INFO - 2025-09-17 07:34:54 --> Config Class Initialized
INFO - 2025-09-17 07:34:54 --> Hooks Class Initialized
DEBUG - 2025-09-17 07:34:54 --> UTF-8 Support Enabled
INFO - 2025-09-17 07:34:54 --> Utf8 Class Initialized
INFO - 2025-09-17 07:34:54 --> URI Class Initialized
DEBUG - 2025-09-17 07:34:54 --> No URI present. Default controller set.
INFO - 2025-09-17 07:34:54 --> Router Class Initialized
INFO - 2025-09-17 07:34:54 --> Output Class Initialized
INFO - 2025-09-17 07:34:54 --> Security Class Initialized
DEBUG - 2025-09-17 07:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-09-17 07:34:54 --> Input Class Initialized
INFO - 2025-09-17 07:34:54 --> Language Class Initialized
INFO - 2025-09-17 07:34:54 --> Loader Class Initialized
INFO - 2025-09-17 07:34:54 --> Helper loaded: url_helper
INFO - 2025-09-17 07:34:54 --> Helper loaded: language_helper
DEBUG - 2025-09-17 07:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-09-17 07:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-09-17 07:34:54 --> Controller Class Initialized
INFO - 2025-09-17 07:34:54 --> File loaded: C:\xampp9\htdocs\bagplayers\application\views\home.php
INFO - 2025-09-17 07:34:54 --> Final output sent to browser
DEBUG - 2025-09-17 07:34:54 --> Total execution time: 0.4131
